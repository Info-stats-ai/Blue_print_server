[
  (comment
    "<%!--"
    "--%>")
  (comment
    "<%#"
    "%>")
] @annotation
