(_
  "{"
  "}" @end) @indent
