(comment) @comment
(string) @string
