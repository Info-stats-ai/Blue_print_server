(pair
  (_)
  "="
  (_) @redact)
