("(" @open
  ")" @close)

("[" @open
  "]" @close)

("{" @open
  "}" @close)

("\"" @open
  "\"" @close)

(payload
  "|" @open
  "|" @close)

("'" @open
  "'" @close)
